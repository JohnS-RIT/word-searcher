# word-searcher
IGME 430 Project 2 - A novel game where users guess words based on information about them. Created to test knowledge and application of MVC with React.js
