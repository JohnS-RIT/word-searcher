module.exports.Account = require('./Account.js');
module.exports.Word = require('./Word.js');
